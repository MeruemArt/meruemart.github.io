echo "======================================"
echo "1. Login en AWS"

# login AWS imagen base 
response=$(aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin 125277160564.dkr.ecr.us-east-1.amazonaws.com)

# login AWS imagen base con productos (número de cuenta varia según el ambiente) 
# response=$(aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin 681989517074.dkr.ecr.us-east-1.amazonaws.com)

echo "Estado de Logeo: $response"

echo "======================================"
echo "2. Ejecutar docker-compose"

if [[ response ]]
then
docker-compose up -d
else
echo "Verifique si tiene actualizada las credenciales"
fi  